package com.abnamro.apps.referenceandroid

import org.junit.Test

import org.junit.Assert.*

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    @Test
    @Throws(Exception::class)
    fun addition_isCorrect() {
        val myClass = Sum()
        val result = myClass.add(2, 2)
        val expected = 4
        assertEquals(expected, result)
    }

    inner class Sum {
        fun add(a: Int, b: Int): Int {
            return a + b
        }
    }
}
